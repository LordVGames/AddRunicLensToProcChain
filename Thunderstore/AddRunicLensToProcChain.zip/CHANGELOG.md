## 1.0.1
- Changed description to help discoverability
- - This is technically a fix mod, but the name/icon/description weren't really saying it is.
- - I'm not changing the name/icon combo since it's funny, but I did re-word the description so people know it's a fix mod
- - (and now it might pop-up when searching "fix"?)

## 1.0.0

- First release