## 1.0.1
- Changed description to help discoverability
- - This is technically a fix mod, but the name/icon/description weren't really saying it is
- - I'm not changing the name/icon combo since it's funny, but I did re-word the description so people know it's a fix mod
- - This should hopefully also make it appear when searching for fix mods

## 1.0.0

- First release